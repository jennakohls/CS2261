
//{{BLOCK(pond3)

//======================================================================
//
//	pond3, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 197 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 6304 + 2048 = 8864
//
//	Time-stamp: 2018-12-02, 23:52:08
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_POND3_H
#define GRIT_POND3_H

#define pond3TilesLen 6304
extern const unsigned short pond3Tiles[3152];

#define pond3MapLen 2048
extern const unsigned short pond3Map[1024];

#define pond3PalLen 512
extern const unsigned short pond3Pal[256];

#endif // GRIT_POND3_H

//}}BLOCK(pond3)
