How to play:
- use the paddle and ball to clear every block on the screen
- if you clear them all, you win
- if the ball falls below the paddle, you will lose a life and one previously cleared block will reappear (come back from the pool). 

Controls:
- press start to begin and to restart from lose/pause/win
- press select to pause
- press the left and right arrow keys to move the paddle 


