
//{{BLOCK(startscreen15)

//======================================================================
//
//	startscreen15, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 391 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 12512 + 2048 = 15072
//
//	Time-stamp: 2018-12-05, 23:08:25
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_STARTSCREEN15_H
#define GRIT_STARTSCREEN15_H

#define startscreen15TilesLen 12512
extern const unsigned short startscreen15Tiles[6256];

#define startscreen15MapLen 2048
extern const unsigned short startscreen15Map[1024];

#define startscreen15PalLen 512
extern const unsigned short startscreen15Pal[256];

#endif // GRIT_STARTSCREEN15_H

//}}BLOCK(startscreen15)
