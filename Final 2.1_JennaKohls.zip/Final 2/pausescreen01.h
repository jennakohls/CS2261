
//{{BLOCK(pausescreen01)

//======================================================================
//
//	pausescreen01, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 476 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 15232 + 2048 = 17792
//
//	Time-stamp: 2018-12-05, 23:29:23
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_PAUSESCREEN01_H
#define GRIT_PAUSESCREEN01_H

#define pausescreen01TilesLen 15232
extern const unsigned short pausescreen01Tiles[7616];

#define pausescreen01MapLen 2048
extern const unsigned short pausescreen01Map[1024];

#define pausescreen01PalLen 512
extern const unsigned short pausescreen01Pal[256];

#endif // GRIT_PAUSESCREEN01_H

//}}BLOCK(pausescreen01)
