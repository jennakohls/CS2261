
//{{BLOCK(startscreen14)

//======================================================================
//
//	startscreen14, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 393 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 12576 + 2048 = 15136
//
//	Time-stamp: 2018-12-05, 23:08:15
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_STARTSCREEN14_H
#define GRIT_STARTSCREEN14_H

#define startscreen14TilesLen 12576
extern const unsigned short startscreen14Tiles[6288];

#define startscreen14MapLen 2048
extern const unsigned short startscreen14Map[1024];

#define startscreen14PalLen 512
extern const unsigned short startscreen14Pal[256];

#endif // GRIT_STARTSCREEN14_H

//}}BLOCK(startscreen14)
