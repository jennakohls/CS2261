
//{{BLOCK(startscreen07)

//======================================================================
//
//	startscreen07, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 437 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 13984 + 2048 = 16544
//
//	Time-stamp: 2018-12-05, 23:06:33
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_STARTSCREEN07_H
#define GRIT_STARTSCREEN07_H

#define startscreen07TilesLen 13984
extern const unsigned short startscreen07Tiles[6992];

#define startscreen07MapLen 2048
extern const unsigned short startscreen07Map[1024];

#define startscreen07PalLen 512
extern const unsigned short startscreen07Pal[256];

#endif // GRIT_STARTSCREEN07_H

//}}BLOCK(startscreen07)
