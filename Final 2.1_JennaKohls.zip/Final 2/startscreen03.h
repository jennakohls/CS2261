
//{{BLOCK(startscreen03)

//======================================================================
//
//	startscreen03, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 436 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 13952 + 2048 = 16512
//
//	Time-stamp: 2018-12-05, 23:05:23
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_STARTSCREEN03_H
#define GRIT_STARTSCREEN03_H

#define startscreen03TilesLen 13952
extern const unsigned short startscreen03Tiles[6976];

#define startscreen03MapLen 2048
extern const unsigned short startscreen03Map[1024];

#define startscreen03PalLen 512
extern const unsigned short startscreen03Pal[256];

#endif // GRIT_STARTSCREEN03_H

//}}BLOCK(startscreen03)
