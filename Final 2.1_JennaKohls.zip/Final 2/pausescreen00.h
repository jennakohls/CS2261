
//{{BLOCK(pausescreen00)

//======================================================================
//
//	pausescreen00, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 475 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 15200 + 2048 = 17760
//
//	Time-stamp: 2018-12-05, 23:29:00
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_PAUSESCREEN00_H
#define GRIT_PAUSESCREEN00_H

#define pausescreen00TilesLen 15200
extern const unsigned short pausescreen00Tiles[7600];

#define pausescreen00MapLen 2048
extern const unsigned short pausescreen00Map[1024];

#define pausescreen00PalLen 512
extern const unsigned short pausescreen00Pal[256];

#endif // GRIT_PAUSESCREEN00_H

//}}BLOCK(pausescreen00)
