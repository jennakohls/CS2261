
//{{BLOCK(startscreen12)

//======================================================================
//
//	startscreen12, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 394 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 12608 + 2048 = 15168
//
//	Time-stamp: 2018-12-05, 23:07:43
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_STARTSCREEN12_H
#define GRIT_STARTSCREEN12_H

#define startscreen12TilesLen 12608
extern const unsigned short startscreen12Tiles[6304];

#define startscreen12MapLen 2048
extern const unsigned short startscreen12Map[1024];

#define startscreen12PalLen 512
extern const unsigned short startscreen12Pal[256];

#endif // GRIT_STARTSCREEN12_H

//}}BLOCK(startscreen12)
