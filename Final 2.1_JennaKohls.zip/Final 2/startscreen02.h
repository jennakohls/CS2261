
//{{BLOCK(startscreen02)

//======================================================================
//
//	startscreen02, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 434 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 13888 + 2048 = 16448
//
//	Time-stamp: 2018-12-05, 23:05:00
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_STARTSCREEN02_H
#define GRIT_STARTSCREEN02_H

#define startscreen02TilesLen 13888
extern const unsigned short startscreen02Tiles[6944];

#define startscreen02MapLen 2048
extern const unsigned short startscreen02Map[1024];

#define startscreen02PalLen 512
extern const unsigned short startscreen02Pal[256];

#endif // GRIT_STARTSCREEN02_H

//}}BLOCK(startscreen02)
