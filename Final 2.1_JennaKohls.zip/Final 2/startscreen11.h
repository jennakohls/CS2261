
//{{BLOCK(startscreen11)

//======================================================================
//
//	startscreen11, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 405 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 12960 + 2048 = 15520
//
//	Time-stamp: 2018-12-05, 23:07:28
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_STARTSCREEN11_H
#define GRIT_STARTSCREEN11_H

#define startscreen11TilesLen 12960
extern const unsigned short startscreen11Tiles[6480];

#define startscreen11MapLen 2048
extern const unsigned short startscreen11Map[1024];

#define startscreen11PalLen 512
extern const unsigned short startscreen11Pal[256];

#endif // GRIT_STARTSCREEN11_H

//}}BLOCK(startscreen11)
