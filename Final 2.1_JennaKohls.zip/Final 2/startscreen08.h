
//{{BLOCK(startscreen08)

//======================================================================
//
//	startscreen08, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 439 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 14048 + 2048 = 16608
//
//	Time-stamp: 2018-12-05, 23:06:48
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_STARTSCREEN08_H
#define GRIT_STARTSCREEN08_H

#define startscreen08TilesLen 14048
extern const unsigned short startscreen08Tiles[7024];

#define startscreen08MapLen 2048
extern const unsigned short startscreen08Map[1024];

#define startscreen08PalLen 512
extern const unsigned short startscreen08Pal[256];

#endif // GRIT_STARTSCREEN08_H

//}}BLOCK(startscreen08)
