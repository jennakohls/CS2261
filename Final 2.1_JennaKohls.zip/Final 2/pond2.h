
//{{BLOCK(pond2)

//======================================================================
//
//	pond2, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 183 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 5856 + 2048 = 8416
//
//	Time-stamp: 2018-12-02, 00:32:26
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_POND2_H
#define GRIT_POND2_H

#define pond2TilesLen 5856
extern const unsigned short pond2Tiles[2928];

#define pond2MapLen 2048
extern const unsigned short pond2Map[1024];

#define pond2PalLen 512
extern const unsigned short pond2Pal[256];

#endif // GRIT_POND2_H

//}}BLOCK(pond2)
