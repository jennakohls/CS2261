
//{{BLOCK(startscreen05)

//======================================================================
//
//	startscreen05, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 445 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 14240 + 2048 = 16800
//
//	Time-stamp: 2018-12-05, 23:06:07
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_STARTSCREEN05_H
#define GRIT_STARTSCREEN05_H

#define startscreen05TilesLen 14240
extern const unsigned short startscreen05Tiles[7120];

#define startscreen05MapLen 2048
extern const unsigned short startscreen05Map[1024];

#define startscreen05PalLen 512
extern const unsigned short startscreen05Pal[256];

#endif // GRIT_STARTSCREEN05_H

//}}BLOCK(startscreen05)
