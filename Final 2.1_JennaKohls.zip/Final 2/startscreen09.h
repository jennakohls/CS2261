
//{{BLOCK(startscreen09)

//======================================================================
//
//	startscreen09, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 448 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 14336 + 2048 = 16896
//
//	Time-stamp: 2018-12-05, 23:07:03
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_STARTSCREEN09_H
#define GRIT_STARTSCREEN09_H

#define startscreen09TilesLen 14336
extern const unsigned short startscreen09Tiles[7168];

#define startscreen09MapLen 2048
extern const unsigned short startscreen09Map[1024];

#define startscreen09PalLen 512
extern const unsigned short startscreen09Pal[256];

#endif // GRIT_STARTSCREEN09_H

//}}BLOCK(startscreen09)
