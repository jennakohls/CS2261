
//{{BLOCK(startscreen00)

//======================================================================
//
//	startscreen00, 256x256@4, 
//	+ palette 256 entries, not compressed
//	+ 466 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 512 + 14912 + 2048 = 17472
//
//	Time-stamp: 2018-12-05, 23:03:11
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_STARTSCREEN00_H
#define GRIT_STARTSCREEN00_H

#define startscreen00TilesLen 14912
extern const unsigned short startscreen00Tiles[7456];

#define startscreen00MapLen 2048
extern const unsigned short startscreen00Map[1024];

#define startscreen00PalLen 512
extern const unsigned short startscreen00Pal[256];

#endif // GRIT_STARTSCREEN00_H

//}}BLOCK(startscreen00)
