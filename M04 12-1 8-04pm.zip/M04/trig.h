const short sin_table[360];
const short cos_table[360];
