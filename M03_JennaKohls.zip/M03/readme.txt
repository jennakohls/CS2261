Hello!

Controls:
- Left and Right arrow keys rotate the player
- Up key propels the player forward
- Down key stops player motion
- A fires a player bullet

- Hit the enemy 10 times to win.
- Get hit by enemy 3 times to lose. 

Well... A is supposed to fire a bullet. This worked beautifully until I added enemy bullets and now I can't get it to work. They are supposed to fire in 8 directions based on where the player is facing. All the code is still in there. 