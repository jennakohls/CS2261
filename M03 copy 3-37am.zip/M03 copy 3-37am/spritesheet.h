
//{{BLOCK(spritesheet)

//======================================================================
//
//	spritesheet, 240x160@4, 
//	+ palette 16 entries, not compressed
//	+ 600 tiles not compressed
//	Total size: 32 + 19200 = 19232
//
//	Time-stamp: 2018-11-27, 00:28:02
//	Exported by Cearn's GBA Image Transmogrifier, v0.8.3
//	( http://www.coranac.com/projects/#grit )
//
//======================================================================

#ifndef GRIT_SPRITESHEET_H
#define GRIT_SPRITESHEET_H

#define spritesheetTilesLen 19200
extern const unsigned short spritesheetTiles[9600];

#define spritesheetPalLen 32
extern const unsigned short spritesheetPal[16];

#endif // GRIT_SPRITESHEET_H

//}}BLOCK(spritesheet)
